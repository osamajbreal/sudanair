<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <title>خدمات سودانير</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- خط عربي -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">

    <!-- ملفات التنسيق -->
    <link rel="stylesheet" href="styles/index.css">
    <link rel="stylesheet" href="styles/header-style.css">
    <link rel="stylesheet" href="styles/footer-style.css">

    <style>
        body {
            font-family: 'Cairo', sans-serif;
            background-color: #f9f9f9;
            color: #222;
            margin: 0;
            padding: 0;
        }

        .services-header {
            background-color: #222; /* نفس لون التذييل */
            color: white;
            text-align: center;
            padding: 60px 10px 40px;
            position: relative;
        }

        .services-header h1 {
            margin: 0;
            font-size: 2.5em;
        }

        .back-button {
            position: absolute;
            top: 15px;
            left: 15px;
            background-color: transparent;
            color: white;
            border: 2px solid white;
            padding: 8px 18px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 1em;
            transition: all 0.3s ease;
        }

        .back-button:hover {
            background-color: white;
            color: #222;
        }

        .lang-toggle {
            position: fixed;
            top: 10px;
            right: 10px;
            background-color: rgba(51, 202, 207, 0.4);
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            z-index: 999;
        }

        .lang-toggle:hover {
            background-color: rgba(40, 167, 69, 0.6);
        }

        .services-section {
            padding: 40px 20px;
        }

        .service-block {
            display: flex;
            flex-wrap: wrap;
            margin-bottom: 40px;
            align-items: center;
            justify-content: center;
        }

        .service-block:nth-child(even) {
            flex-direction: row-reverse;
        }

        .service-img {
            flex: 1;
            min-width: 280px;
            max-width: 400px;
            padding: 10px;
        }

        .service-img img {
            width: 100%;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .service-text {
            flex: 1;
            min-width: 280px;
            padding: 20px;
        }

        .service-text h2 {
            margin-bottom: 15px;
            color: #007bff;
        }

        .service-text p {
            font-size: 1.1em;
            line-height: 1.7;
        }

        footer {
            background-color: #222;
            color: white;
            padding: 30px 20px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        footer h3 {
            color: #fff;
            margin-bottom: 10px;
        }

        .about, .contacts, .follow-us {
            flex: 1;
            min-width: 250px;
            margin-bottom: 20px;
        }

        .contacts-side .contact a {
            color: #ccc;
            text-decoration: none;
        }

        .contacts-side .contact a:hover {
            text-decoration: underline;
        }

        .madia a img {
            width: 30px;
            margin-left: 10px;
        }

        /* استعلامات الوسائط لتوافق الأجهزة */
        @media (max-width: 768px) {
            .services-header h1 {
                font-size: 2em;
            }

            .service-block {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }

            .service-img {
                min-width: 100%;
                max-width: 90%;
            }

            .service-text {
                padding: 15px;
            }

            .back-button {
                font-size: 0.9em;
                padding: 6px 14px;
            }

            .lang-toggle {
                font-size: 14px;
                padding: 6px 12px;
            }
        }

        @media (max-width: 480px) {
            .services-header h1 {
                font-size: 1.7em;
            }

            .service-block {
                margin-bottom: 30px;
            }

            .service-img img {
                border-radius: 8px;
            }

            footer {
                padding: 20px 10px;
            }

            .about, .contacts, .follow-us {
                flex: 1 100%;
                text-align: center;
            }

            .contacts-side .contact {
                font-size: 0.9em;
            }

            .madia a img {
                width: 25px;
            }
        }
    </style>
</head>
<body>

    <!-- زر تغيير اللغة -->
    <button onclick="toggleLanguage()" class="lang-toggle" id="langBtn">English</button>

    <!-- رأس الصفحة + زر الرجوع -->
    <div class="services-header">
        <a href="index.php" class="back-button">الرجوع</a>
        <h1>خدمات سودانير</h1>
    </div>

    <!-- قسم الخدمات -->
    <div class="services-section">

        <!-- الشحن الجوي -->
        <div class="service-block">
            <div class="service-img">
                <img src="imgs/s1.png" alt="الشحن الجوي">
            </div>
            <div class="service-text">
                <h2>الشحن الجوي</h2>
                <p>
                    نوفر خدمات شحن جوي موثوقة وسريعة لمختلف الوجهات حول العالم، باستخدام أسطولنا الجوي المجهز ومراكزنا اللوجستية المدعومة بأحدث التقنيات.
                </p>
            </div>
        </div>

        <!-- المناولة الأرضية -->
        <div class="service-block">
            <div class="service-img">
                <img src="imgs/j2.png" alt="المناولة الأرضية">
            </div>
            <div class="service-text">
                <h2>خدمات المناولة الأرضية</h2>
                <p>
                    نقدم حلول متكاملة للمناولة الأرضية تشمل تحميل وتفريغ الأمتعة، استقبال وتوديع الركاب، وخدمات الوقود، مما يضمن تشغيلًا سلسًا وآمنًا للرحلات.
                </p>
            </div>
        </div>

        <!-- الخدمات الهندسية -->
        <div class="service-block">
            <div class="service-img">
                <img src="imgs/s2.png" alt="الخدمات الهندسية">
            </div>
            <div class="service-text">
                <h2>الخدمات الهندسية</h2>
                <p>
                    يضم قسمنا الهندسي فريقًا من المهندسين والفنيين المعتمدين لصيانة الطائرات، مما يضمن أعلى معايير السلامة والجودة وفقًا للوائح الدولية.
                </p>
            </div>
        </div>

        <!-- خدمات خاصة -->
        <div class="service-block">
            <div class="service-img">
                <img src="imgs/j1.png" alt="خدمات خاصة">
            </div>
            <div class="service-text">
                <h2>خدمات خاصة</h2>
                <p>
                    نلبي احتياجات عملائنا المميزة من خلال تقديم خدمات مخصصة مثل رحلات كبار الشخصيات، وخدمات الإخلاء الطبي، ورحلات التأجير الخاصة.
                </p>
            </div>
        </div>

    </div>

    <!-- التذييل -->
    <footer id="about">
        <div class="about">
            <h3>من نحن</h3>
            <p>
                الخطوط الجوية السودانية هي الناقل الوطني الرسمي، وتهدف إلى تقديم أفضل خدمات الطيران للمسافرين من وإلى السودان، مع الالتزام بالجودة والسلامة والمواعيد.
            </p>
        </div>
        <div class="contacts">
            <h3>تواصل معنا</h3>
            <div class="contacts-side">
                <div class="contact">السودان</div>
                <div class="contact"><a href="tel:+249912110765">+249912110765</a></div>
                <div class="contact"><a href="mailto:info@sudanair.sd">info@sudanair.sd</a></div>
                <div class="contact">24 ساعة</div>
            </div>
        </div>
    </footer>

    <!-- سكريبت تبديل اللغة -->
    <script>
        let currentLang = localStorage.getItem("lang") || "ar";

        function applyLanguage(lang) {
            const langBtn = document.getElementById("langBtn");

            if (lang === "en") {
                document.documentElement.lang = "en";
                document.documentElement.dir = "ltr";
                langBtn.textContent = "العربية";

                document.querySelector(".back-button").textContent = "Back";
                document.querySelector(".services-header h1").textContent = "Sudan Airways Services";

                const titles = document.querySelectorAll(".service-text h2");
                const paragraphs = document.querySelectorAll(".service-text p");

                titles[0].textContent = "Air Cargo";
                paragraphs[0].textContent = "We provide reliable and fast air cargo services to various destinations around the world using our equipped fleet and modern logistics hubs.";

                titles[1].textContent = "Ground Handling Services";
                paragraphs[1].textContent = "We offer integrated ground handling solutions including baggage handling, passenger reception, fueling, and more for safe and efficient operations.";

                titles[2].textContent = "Engineering Services";
                paragraphs[2].textContent = "Our engineering division includes certified engineers and technicians ensuring top-notch aircraft maintenance that meets international standards.";

                titles[3].textContent = "Special Services";
                paragraphs[3].textContent = "We meet our clients’ unique needs with customized services such as VIP flights, medical evacuation, and private charter flights.";

                document.querySelector("footer h3").textContent = "About Us";
                document.querySelector(".about p").textContent = "Sudan Airways is the official national carrier, aiming to provide high-quality air services with commitment to safety, quality, and punctuality.";
                document.querySelector(".contacts h3").textContent = "Contact Us";
                document.querySelectorAll(".contacts-side .contact")[0].textContent = "Sudan";
                document.querySelectorAll(".contacts-side .contact")[3].textContent = "24 Hr";

                currentLang = "en";
            } else {
                document.documentElement.lang = "ar";
                document.documentElement.dir = "rtl";
                langBtn.textContent = "English";

                document.querySelector(".back-button").textContent = "الرجوع";
                document.querySelector(".services-header h1").textContent = "خدمات سودانير";

                const titles = document.querySelectorAll(".service-text h2");
                const paragraphs = document.querySelectorAll(".service-text p");

                titles[0].textContent = "الشحن الجوي";
                paragraphs[0].textContent = "نوفر خدمات شحن جوي موثوقة وسريعة لمختلف الوجهات حول العالم، باستخدام أسطولنا الجوي المجهز ومراكزنا اللوجستية المدعومة بأحدث التقنيات.";

                titles[1].textContent = "خدمات المناولة الأرضية";
                paragraphs[1].textContent = "نقدم حلول متكاملة للمناولة الأرضية تشمل تحميل وتفريغ الأمتعة، استقبال وتوديع الركاب، وخدمات الوقود، مما يضمن تشغيلًا سلسًا وآمنًا للرحلات.";

                titles[2].textContent = "الخدمات الهندسية";
                paragraphs[2].textContent = "يضم قسمنا الهندسي فريقًا من المهندسين والفنيين المعتمدين لصيانة الطائرات، مما يضمن أعلى معايير السلامة والجودة وفقًا للوائح الدولية.";

                titles[3].textContent = "خدمات خاصة";
                paragraphs[3].textContent = "نلبي احتياجات عملائنا المميزة من خلال تقديم خدمات مخصصة مثل رحلات كبار الشخصيات، وخدمات الإخلاء الطبي، ورحلات التأجير الخاصة.";

                document.querySelector("footer h3").textContent = "من نحن";
                document.querySelector(".about p").textContent = "الخطوط الجوية السودانية هي الناقل الوطني الرسمي، وتهدف إلى تقديم أفضل خدمات الطيران للمسافرين من وإلى السودان، مع الالتزام بالجودة والسلامة والمواعيد.";
                document.querySelector(".contacts h3").textContent = "تواصل معنا";
                document.querySelectorAll(".contacts-side .contact")[0].textContent = "السودان";
                document.querySelectorAll(".contacts-side .contact")[3].textContent = "24 ساعة";

                currentLang = "ar";
            }

            localStorage.setItem("lang", currentLang);
        }

        function toggleLanguage() {
            applyLanguage(currentLang === "ar" ? "en" : "ar");
        }

        applyLanguage(currentLang);
    </script>

</body>
</html>
