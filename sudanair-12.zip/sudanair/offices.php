<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>مكاتبنا - سودانير</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- الخط -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">

    <!-- تنسيقات خارجية -->
    <link rel="stylesheet" href="styles/index.css">
    <link rel="stylesheet" href="styles/header-style.css">
    <link rel="stylesheet" href="styles/footer-style.css">

    <style>
        body {
            font-family: 'Cairo', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f4f8;
        }

        .header-bar {
            background: linear-gradient(to left, #004466, #007b8a);
            color: white;
            text-align: center;
            padding: 60px 10px 40px;
            position: relative;
        }

        .header-bar h1 {
            margin: 0;
            font-size: 2.8em;
        }

        .lang-toggle,
        .back-button {
            position: absolute;
            top: 15px;
            padding: 8px 16px;
            border-radius: 6px;
            border: 2px solid white;
            background-color: transparent;
            color: white;
            cursor: pointer;
            transition: 0.3s ease;
            font-size: 1em;
        }

        .lang-toggle:hover,
        .back-button:hover {
            background-color: white;
            color: #004466;
        }

        .lang-toggle {
            right: 15px;
        }

        .back-button {
            left: 15px;
            text-decoration: none;
        }

        .offices-section {
            padding: 50px 20px;
            display: flex;
            flex-direction: column;
            gap: 30px;
            align-items: center;
        }

        .office-box {
            background-color: white;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
            text-align: center;
            transition: transform 0.3s ease;
        }

        .office-box:hover {
            transform: translateY(-5px);
        }

        .office-box h2 {
            color: #007b8a;
            margin-bottom: 12px;
        }

        .office-box a {
            color: #004466;
            text-decoration: none;
            font-size: 1.1em;
        }

        .office-box a:hover {
            text-decoration: underline;
        }

        footer {
            background: linear-gradient(to left, #002f4b, #004466);
            color: white;
            padding: 40px 30px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: flex-start;
            gap: 30px;
        }

        .footer-section {
            flex: 1;
            min-width: 250px;
        }

        .footer-section h3 {
            margin-top: 0;
            margin-bottom: 15px;
            font-size: 1.3em;
            border-bottom: 2px solid white;
            padding-bottom: 5px;
        }

        .footer-section p,
        .footer-section a,
        .footer-section div {
            font-size: 1em;
            margin: 8px 0;
            color: #ddd;
            text-decoration: none;
        }

        .footer-section a:hover {
            text-decoration: underline;
            color: #fff;
        }

        /* استجابة الشاشات الصغيرة */
        @media (max-width: 768px) {
            .header-bar h1 {
                font-size: 2em;
            }

            .lang-toggle,
            .back-button {
                font-size: 14px;
                padding: 6px 12px;
            }

            .office-box {
                padding: 20px;
            }

            footer {
                flex-direction: column;
                text-align: center;
            }

            .footer-section h3 {
                border: none;
            }
        }

        @media (max-width: 480px) {
            .header-bar {
                padding: 40px 10px 30px;
            }

            .header-bar h1 {
                font-size: 1.8em;
            }

            .lang-toggle,
            .back-button {
                font-size: 12px;
                padding: 5px 10px;
            }

            .office-box {
                padding: 16px;
            }
        }
    </style>
</head>
<body>

    <div class="header-bar">
        <a href="index.php" class="back-button">الرجوع</a>
        <button onclick="toggleLanguage()" class="lang-toggle" id="langBtn">English</button>
        <h1 id="pageTitle">مكاتبنا</h1>
    </div>

    <div class="offices-section">
        <div class="office-box">
            <h2 id="office1">مكتب بورتسودان</h2>
            <a href="https://maps.app.goo.gl/suR1P2kztxDWSVR67?g_st=com.google.maps.preview.copy" target="_blank">عرض على الخريطة</a>
        </div>

        <div class="office-box">
            <h2 id="office2">مكتب جدة</h2>
            <a href="https://maps.app.goo.gl/k5ng4EDjzMydVXHV9?g_st=com.google.maps.preview.copy" target="_blank">عرض على الخريطة</a>
        </div>

        <div class="office-box">
            <h2 id="office3">مكتب القاهرة</h2>
            <a href="https://maps.app.goo.gl/Rbxm5QHN1xZeRoHo6?g_st=com.google.maps.preview.copy" target="_blank">عرض على الخريطة</a>
        </div>
    </div>

    <footer>
        <div class="footer-section">
            <h3 id="aboutTitle">من نحن</h3>
            <p id="aboutDesc">
                الخطوط الجوية السودانية هي الناقل الوطني الرسمي، وتهدف إلى تقديم أفضل خدمات الطيران للمسافرين من وإلى السودان، مع الالتزام بالجودة والسلامة والمواعيد.
            </p>
        </div>
        <div class="footer-section">
            <h3 id="contactTitle">تواصل معنا</h3>
            <div id="country">السودان</div>
            <a href="tel:+249912110765">+249912110765</a>
            <a href="mailto:info@sudanair.sd">info@sudanair.sd</a>
            <div id="hours">24 ساعة</div>
        </div>
    </footer>

    <script>
        let currentLang = localStorage.getItem("lang") || "ar";

        function applyLanguage(lang) {
            document.documentElement.lang = lang;
            document.documentElement.dir = lang === "en" ? "ltr" : "rtl";

            const isArabic = lang === "ar";
            document.getElementById("langBtn").textContent = isArabic ? "English" : "العربية";
            document.getElementById("pageTitle").textContent = isArabic ? "مكاتبنا" : "Our Offices";
            document.getElementById("office1").textContent = isArabic ? "مكتب بورتسودان" : "Port Sudan Office";
            document.getElementById("office2").textContent = isArabic ? "مكتب جدة" : "Jeddah Office";
            document.getElementById("office3").textContent = isArabic ? "مكتب القاهرة" : "Cairo Office";
            document.getElementById("aboutTitle").textContent = isArabic ? "من نحن" : "About Us";
            document.getElementById("aboutDesc").textContent = isArabic
                ? "الخطوط الجوية السودانية هي الناقل الوطني الرسمي، وتهدف إلى تقديم أفضل خدمات الطيران للمسافرين من وإلى السودان، مع الالتزام بالجودة والسلامة والمواعيد."
                : "Sudan Airways is the official national carrier, aiming to provide the best air services with a commitment to quality, safety, and punctuality.";
            document.getElementById("contactTitle").textContent = isArabic ? "تواصل معنا" : "Contact Us";
            document.getElementById("country").textContent = isArabic ? "السودان" : "Sudan";
            document.getElementById("hours").textContent = isArabic ? "24 ساعة" : "24 Hr";

            localStorage.setItem("lang", lang);
        }

        function toggleLanguage() {
            applyLanguage(currentLang === "ar" ? "en" : "ar");
            currentLang = currentLang === "ar" ? "en" : "ar";
        }

        applyLanguage(currentLang);
    </script>

</body>
</html>
