<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إعلان - سودانير</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- الخط -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">

    <!-- تنسيقات خارجية -->
    <link rel="stylesheet" href="styles/index.css">
    <link rel="stylesheet" href="styles/header-style.css">
    <link rel="stylesheet" href="styles/footer-style.css">

    <style>
        body {
            font-family: 'Cairo', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #fff7f0;
        }

        .header-bar {
            background: linear-gradient(to left, #800000, #b22222);
            color: white;
            text-align: center;
            padding: 60px 10px 40px;
            position: relative;
        }

        .header-bar h1 {
            margin: 0;
            font-size: 2.8em;
        }

        .lang-toggle,
        .back-button {
            position: absolute;
            top: 15px;
            padding: 8px 16px;
            border-radius: 6px;
            border: 2px solid white;
            background-color: transparent;
            color: white;
            cursor: pointer;
            transition: 0.3s ease;
            font-size: 1em;
        }

        .lang-toggle:hover,
        .back-button:hover {
            background-color: white;
            color: #800000;
        }

        .lang-toggle {
            right: 15px;
        }

        .back-button {
            left: 15px;
            text-decoration: none;
        }

        .announcement-section {
            padding: 60px 30px;
            max-width: 800px;
            margin: auto;
            background-color: white;
            border-radius: 16px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
            color: #333;
            font-size: 1.2em;
            line-height: 1.8;
        }

        footer {
            background: linear-gradient(to left, #4b0000, #800000);
            color: white;
            padding: 40px 30px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: flex-start;
            gap: 30px;
        }

        .footer-section {
            flex: 1;
            min-width: 250px;
        }

        .footer-section h3 {
            margin-top: 0;
            margin-bottom: 15px;
            font-size: 1.3em;
            border-bottom: 2px solid white;
            padding-bottom: 5px;
        }

        .footer-section p,
        .footer-section a,
        .footer-section div {
            font-size: 1em;
            margin: 8px 0;
            color: #ddd;
            text-decoration: none;
        }

        .footer-section a:hover {
            text-decoration: underline;
            color: #fff;
        }

        @media (max-width: 768px) {
            .header-bar h1 {
                font-size: 2em;
            }

            .lang-toggle,
            .back-button {
                font-size: 14px;
                padding: 6px 12px;
            }

            .announcement-section {
                padding: 30px 15px;
            }

            footer {
                flex-direction: column;
                text-align: center;
            }

            .footer-section h3 {
                border: none;
            }
        }
    </style>
</head>
<body>
    <div class="header-bar">
        <a href="index.php" class="back-button">الرجوع</a>
        <button onclick="toggleLanguage()" class="lang-toggle" id="langBtn">English</button>
        <h1 id="pageTitle">إعلان</h1>
    </div>

    <div class="announcement-section" id="announcementContent">
        سودانير تطالب العشرة الأوائل للشهادة السودانية الحضور إلى مكاتبها.<br><br>
        <strong>بورتسودان: طيران بلدنا</strong><br><br>
        في إطار المسؤولية المجتمعية وبوصفها الناقل الوطني، أعلنت الخطوط الجوية السودانية عن تكريم العشرة الأوائل لإمتحانات الشهادة السودانية المؤجلة لعام 2023.<br><br>
        وقررت سودانير منحهم تذاكر سفر إكرامية على الدرجة الأولى إلى أي وجهة تصلها. وناشدت الطلاب التوجه إلى مكاتب الشركة ببورتسودان، القاهرة، جدة، أو الرياض لاستلام جوائزهم.<br><br>
        للاستفسار: 0024903129915
    </div>
    <!-- 🖼 صورة -->
<h3>صورة توضيحية:</h3>
<img src="announcement-image.jpg" alt="صورة إعلان" width="500">

<!-- 🎥 فيديو -->
<h3>فيديو توضيحي:</h3>
<video width="640" height="360" autoplay muted loop>
    <source src="announcement-video.mp4" type="video/mp4">
    متصفحك لا يدعم تشغيل الفيديو.
</video>
    <footer>
        <div class="footer-section">
            <h3 id="aboutTitle">من نحن</h3>
            <p id="aboutDesc">
                الخطوط الجوية السودانية هي الناقل الوطني الرسمي، وتهدف إلى تقديم أفضل خدمات الطيران للمسافرين من وإلى السودان، مع الالتزام بالجودة والسلامة والمواعيد.
            </p>
        </div>
        <div class="footer-section">
            <h3 id="contactTitle">تواصل معنا</h3>
            <div id="country">السودان</div>
            <a href="tel:+249912110765">+249912110765</a>
            <a href="mailto:info@sudanair.sd">info@sudanair.sd</a>
            <div id="hours">24 ساعة</div>
        </div>
    </footer>

    <script>
        let currentLang = localStorage.getItem("lang") || "ar";

        function applyLanguage(lang) {
            document.documentElement.lang = lang;
            document.documentElement.dir = lang === "en" ? "ltr" : "rtl";

            const isArabic = lang === "ar";
            document.getElementById("langBtn").textContent = isArabic ? "English" : "العربية";
            document.getElementById("pageTitle").textContent = isArabic ? "إعلان" : "Announcement";
            document.getElementById("aboutTitle").textContent = isArabic ? "من نحن" : "About Us";
            document.getElementById("aboutDesc").textContent = isArabic
                ? "الخطوط الجوية السودانية هي الناقل الوطني الرسمي، وتهدف إلى تقديم أفضل خدمات الطيران للمسافرين من وإلى السودان، مع الالتزام بالجودة والسلامة والمواعيد."
                : "Sudan Airways is the official national carrier, aiming to provide the best air services with a commitment to quality, safety, and punctuality.";
            document.getElementById("contactTitle").textContent = isArabic ? "تواصل معنا" : "Contact Us";
            document.getElementById("country").textContent = isArabic ? "السودان" : "Sudan";
            document.getElementById("hours").textContent = isArabic ? "24 ساعة" : "24 Hr";

            document.getElementById("announcementContent").innerHTML = isArabic ?
                `سودانير تطالب العشرة الأوائل للشهادة السودانية الحضور إلى مكاتبها.<br><br>
                <strong>بورتسودان: طيران بلدنا</strong><br><br>
                في إطار المسؤولية المجتمعية وبوصفها الناقل الوطني، أعلنت الخطوط الجوية السودانية عن تكريم العشرة الأوائل لإمتحانات الشهادة السودانية المؤجلة لعام 2023.<br><br>
                وقررت سودانير منحهم تذاكر سفر إكرامية على الدرجة الأولى إلى أي وجهة تصلها. وناشدت الطلاب التوجه إلى مكاتب الشركة ببورتسودان، القاهرة، جدة، أو الرياض لاستلام جوائزهم.<br><br>
                للاستفسار: 0024903129915`
                :
                `Sudan Airways requests the top 10 Sudanese Certificate exam achievers to visit its offices.<br><br>
                <strong>Port Sudan: Our Nation's Airline</strong><br><br>
                As part of its social responsibility and as the national carrier, Sudan Airways has announced an honorary reward for the top 10 students of the postponed 2023 Sudanese Certificate exams.<br><br>
                The airline will offer them complimentary first-class tickets to any destination it serves. Students are requested to visit the company offices in Port Sudan, Cairo, Jeddah, or Riyadh to collect their prizes.<br><br>
                For inquiries: 0024903129915`;

            localStorage.setItem("lang", lang);
        }

        function toggleLanguage() {
            applyLanguage(currentLang === "ar" ? "en" : "ar");
            currentLang = currentLang === "ar" ? "en" : "ar";
        }

        applyLanguage(currentLang);
    </script>
</body>
</html>