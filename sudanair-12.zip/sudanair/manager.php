<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>كلمة المدير العام</title>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Cairo', sans-serif;
      margin: 0;
      background-color: #f5f7fa;
      color: #333;
      direction: rtl;
    }

    header {
      background-color: #002b5c;
      color: white;
      text-align: center;
      padding: 50px 20px;
      border-bottom-left-radius: 40px;
      border-bottom-right-radius: 40px;
      position: relative;
    }

    header h1 {
      margin: 0;
      font-size: 2.5em;
    }

    .lang-toggle {
      position: absolute;
      top: 15px;
      left: 15px;
      background-color: rgba(255, 255, 255, 0.2);
      color: white;
      border: none;
      padding: 8px 14px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 15px;
    }

    .lang-toggle:hover {
      background-color: rgba(255, 255, 255, 0.35);
    }

    main {
      max-width: 1000px;
      margin: 40px auto;
      background-color: white;
      padding: 30px 20px;
      border-radius: 15px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    h2 {
      font-size: 1.8em;
      color: #007bff;
    }

    h3 {
      font-size: 1.2em;
      margin-top: 20px;
      color: #444;
    }

    p {
      line-height: 1.8;
      font-size: 1.1em;
    }

    .images {
      margin-top: 30px;
      display: flex;
      gap: 15px;
      flex-wrap: wrap;
      justify-content: center;
    }

    .images img {
      width: 220px;
      height: 150px;
      object-fit: cover;
      border-radius: 10px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.2);
      transition: transform 0.3s ease;
    }

    .images img:hover {
      transform: scale(1.05);
    }

    footer {
      background-color: #002b5c;
      color: white;
      padding: 40px 20px;
      border-top-left-radius: 40px;
      border-top-right-radius: 40px;
      margin-top: 50px;
      text-align: center;
    }

    .back-button {
      margin-top: 20px;
      padding: 10px 25px;
      font-size: 16px;
      background-color: #007bff;
      border: none;
      color: white;
      border-radius: 6px;
      cursor: pointer;
    }

    .back-button:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>
  <header>
    <h1 id="page-title">كلمة المدير العام</h1>
    <button class="lang-toggle" onclick="toggleLanguage()">English</button>
  </header>

  <main>
    <h3 id="director">المدير العام: شركة الخطوط الجوية السودانية</h3>
    <p id="description">
      تحية إجلال وتقدير لتاريخ "الخطوط الجويةالسودانية" العريق، تلك الشركة التي تأسست عام 1947 لتكون بحق نبض السودان المتصل بالعالم. منذ بداياتها المتواضعة، حملت "سودانير" أحلام وآمال السودانيين، مرسخة طموحاتهم، ومجسدة جسراً للتواصل الحضاري والثقافي والاقتصادي بين وطننا الغالي وشعوب العالم أجمع.<br>
      لم تقتصر رسالة الشركة على ربط السودان بالعالم الخارجي فحسب، بل امتدت لتشمل توثيق الروابط الداخلية، مسهلة حركة الأفراد والبضائع بين ولايات الوطن المختلفة، ومساهمة بذلك في تعزيز الوحدة الوطنية والتنمية الشاملة.<br>
      وعلى امتداد عقود، كانت "سودانير" معقلاً لتخريج أجيال من الطيارين الأكفاء، والمهندسين المهرة، وموظفي الخدمات المتميزين، الذين انتشروا في أصقاع المعمورة، حاملين معهم أسمى صفات الشعب السوداني من دماثة الخلق، ونبل السجايا، وطيب المعشر، وتواضع العلماء، ليساهموا بخبراتهم القيمة في مسيرة العديد من شركات الطيران العالمية والمؤسسات ذات الصلة بصناعة الطيران. لقد كانت الخطوط الجوية السودانية بحق مدرسة عريقة أثرت قطاع الطيران بإسهاماتها الجليلة.<br>
      واليوم، ونحن نواجه تحديات جمة، نستمد القوة والعزيمة من هذا التاريخ المشرّف الحافل بالإنجازات، ومن عبق إرث أرضنا الضارب بجذوره في أعماق تاريخ الإنسانية. بحنكة وبسالة معهودة، قاومت "الخطوط الجويةالسودانية" الصعاب، وظلت شامخة في وجه التحديات، وإيماننا راسخ بأن هذا الإرث العظيم كفيل بإعادتها إلى أوج تألقها.<br>
      إننا نعمل بدأب ومثابرة لوضع خطط طموحة للنهوض بالشركة من جديد، كطائر الفينيق الذي ينبعث من الرماد. عازمون على إعادتها  إلى مكانتها اللائقة بين شركات الطيران الإقليمية والعالمية. وقريباً جداً، سيشهد السودان والعالم بأسره "سودانير" في حلة جديدة، أكثر قوة وحداثة وتطوراً.<br>
      فترقبونا، فالمستقبل يحمل في طياته بشائر الخير لـ "الخطوط الجويةالسودانية" وللسودان.
    </p>

    <div class="images">
      <img src="imgs/a1.png" alt="صورة طيران 1" />
      <img src="imgs/a2.png" alt="صورة طيران 2" />
      <img src="imgs/a3.png" alt="صورة طيران 3" />
      <img src="imgs/a4.png" alt="صورة طيران 4" />
      <img src="imgs/a5.png" alt="صورة طيران 5" />
      <img src="imgs/a6.png" alt="صورة طيران 6" />
      <img src="imgs/a7.png" alt="صورة طيران 7" />
      <img src="imgs/a8.png" alt="صورة طيران 8" />
    </div>
  </main>

  <footer>
    <p>&copy; 2025 سودانير - جميع الحقوق محفوظة</p>
    <button class="back-button" onclick="goToHome()">الرجوع إلى القائمة الرئيسية</button>
  </footer>

  <script>
    function toggleLanguage() {
      const lang = document.documentElement.lang === 'ar' ? 'en' : 'ar';
      document.documentElement.lang = lang;
      document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';

      document.getElementById('page-title').textContent = lang === 'ar' ? 'كلمة المدير العام' : 'General Manager Speech';
      document.getElementById('director').textContent = lang === 'ar'
        ? 'المدير العام: شركة الخطوط الجوية السودانية'
        : 'General Manager: Sudan Airways Company';

      document.getElementById('description').innerHTML = lang === 'ar'
        ? `تحية إجلال وتقدير لتاريخ "الخطوط الجويةالسودانية" العريق، تلك الشركة التي تأسست عام 1947...`
        : `A tribute to the long-standing history of Sudan Airways, a company founded in 1947 that truly represents Sudan’s connection to the world. From its modest beginnings, Sudan Airways carried the hopes and dreams of Sudanese people, embodying their ambitions and serving as a bridge for cultural, economic, and civilizational exchange.<br>
        The company’s mission extended beyond connecting Sudan to the outside world; it also worked to strengthen internal ties by facilitating movement between the country's states, supporting national unity and comprehensive development.<br>
        For decades, Sudan Airways was a hub for producing generations of skilled pilots, engineers, and outstanding service staff who spread across the globe, carrying the finest traits of the Sudanese people—kindness, dignity, humility, and professionalism—and contributing their expertise to the global aviation industry. Sudan Airways was a true school of excellence.<br>
        Today, facing great challenges, we draw strength from this honorable history. With resilience, Sudan Airways has endured hardships and remains determined to reclaim its glory.<br>
        We are working diligently on ambitious plans to revive the company like a phoenix rising from the ashes, aiming to return it to its deserved status among regional and international airlines. Very soon, Sudan and the world will witness Sudan Airways reborn, stronger, more modern, and progressive.<br>
        Stay tuned—the future holds great promise for Sudan Airways and for Sudan.`;
      
      document.querySelector(".lang-toggle").textContent = lang === "ar" ? "English" : "العربية";
    }

    function goToHome() {
      window.location.href = "index.php";
    }
  </script>
</body>
</html>
