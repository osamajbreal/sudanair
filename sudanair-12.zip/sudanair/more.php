<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>عن سودانير</title>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Cairo', sans-serif;
      margin: 0;
      background-color: #f5f7fa;
      color: #333;
      direction: rtl;
    }

    header {
      background-color: #002b5c;
      color: white;
      text-align: center;
      padding: 50px 20px;
      border-bottom-left-radius: 40px;
      border-bottom-right-radius: 40px;
      position: relative;
    }

    header h1 {
      margin: 0;
      font-size: 2.5em;
    }

    .lang-toggle {
      position: absolute;
      top: 15px;
      left: 15px;
      background-color: rgba(255, 255, 255, 0.2);
      color: white;
      border: none;
      padding: 8px 14px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 15px;
    }

    .lang-toggle:hover {
      background-color: rgba(255, 255, 255, 0.35);
    }

    main {
      max-width: 1000px;
      margin: 40px auto;
      background-color: white;
      padding: 30px 20px;
      border-radius: 15px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    h2 {
      font-size: 1.8em;
      color: #007bff;
      margin-bottom: 15px;
    }

    p {
      line-height: 1.8;
      font-size: 1.1em;
      margin-bottom: 20px;
    }

    footer {
      background-color: #002b5c;
      color: white;
      padding: 40px 20px;
      border-top-left-radius: 40px;
      border-top-right-radius: 40px;
      margin-top: 50px;
      text-align: center;
    }

    .back-button {
      margin-top: 20px;
      padding: 10px 25px;
      font-size: 16px;
      background-color: #007bff;
      border: none;
      color: white;
      border-radius: 6px;
      cursor: pointer;
    }

    .back-button:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>
  <header>
    <h1 id="page-title">عن سودانير</h1>
    <button class="lang-toggle" onclick="toggleLanguage()">English</button>
  </header>

  <main>
    <section>
      <p id="content-text">
        تُعتبر الخطوط الجوية السودانية، المعروفة باسم "سودانير" (Sudan Airways)، الذراع الجوية للسودان منذ تأسيسها عام ١٩٤٦، مما يجعلها واحدة من أقدم شركات الطيران في أفريقيا والعالم العربي. نشأت بعد الحرب العالمية الثانية، بدأت رحلتها بطائرات دوغلاس دي سي-٣، وساهمت في ربط السودان بالعالم خلال حقبة الاستعمار البريطاني-المصري.<br><br>

        <strong>التاريخ: من التأسيس إلى التوسع</strong><br>
        بدأت "سودانير" برحلات محلية وإقليمية، ثم توسعت في الستينيات والسبعينيات بأسطول حديث شمل طائرات مثل البوينغ ٧٠٧ و٧٣٧، بالإضافة إلى طائرات "فوكر إف-٢٧" للرحلات القصيرة. بحلول الثمانينيات، أصبحت تُشغل رحلات منتظمة إلى أوروبا (لندن، فرانكفورت)، وإلى دول عربية مثل مصر والسعودية، ودول أفريقية ككينيا وإثيوبيا.<br><br>

        <strong>الشبكة والأسطول: بين الماضي والحاضر</strong><br>
        امتلكت الشركة تاريخياً أسطولاً متنوعاً، لكنه تراجع بسبب العقوبات الاقتصادية ونقص الصيانة. تشمل الطائرات التي استخدمتها:<br>
        - طائرات الركاب: بوينغ ٧٠٧، ٧٣٧، إيرباص إيه٣٠٠، وإيه٣٢٠.<br>
        - طائرات شحن: مثل أنتونوف.<br>
        - طائرات إقليمية: فوكر ٥٠ و٥٠٠.<br>
        أما الشبكة، فشملت محطات محلية كجوبا (قبل انفصال جنوب السودان)، وبورتسودان، وأقاليم دارفور، ودولياً إلى القاهرة، دبي، جدة، وإسطنبول.<br><br>

        <strong>التحديات: عقبات اقتصادية وسياسية</strong><br>
        واجهت "سودانير" تحديات جسيمة:<br>
        1. العقوبات الدولية، خاصة منذ التسعينيات.<br>
        2. انفصال جنوب السودان عام ٢٠١١.<br>
        3. الحظر الأوروبي في ٢٠٠٨.<br>
        4. الأزمات الداخلية (دارفور، الأزمة الاقتصادية، الاضطرابات السياسية).<br>
        5. كوفيد-١٩ والحرب الأهلية ٢٠٢٣.<br><br>

        <strong>محاولات التطوير والصمود</strong><br>
        - شراء طائرات مستعملة مثل إيرباص إيه٣٢٠.<br>
        - شراكات مع شركات مثل الخطوط الإثيوبية.<br>
        - مبادرات حكومية لإعادة الهيكلة وخصخصة جزئية.<br><br>

        <strong>الدور الثقافي والاقتصادي</strong><br>
        ظلت "سودانير" رمزاً للفخر الوطني، ووسيلة حيوية لربط المناطق النائية، خاصة في دارفور وكردفان، كما ساهمت في تنشيط السياحة الدينية (مثل زيارة أهرامات مروي).
      </p>
    </section>
  </main>

  <footer>
    <p>&copy; 2025 سودانير - جميع الحقوق محفوظة</p>
    <button class="back-button" onclick="goToHome()">الرجوع إلى القائمة الرئيسية</button>
  </footer>

  <script>
    function toggleLanguage() {
      const lang = document.documentElement.lang === 'ar' ? 'en' : 'ar';
      document.documentElement.lang = lang;
      document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';

      document.getElementById('page-title').textContent = lang === 'ar'
        ? 'عن سودانير'
        : 'About Sudanair';

      document.title = lang === 'ar' ? 'عن سودانير' : 'About Sudan Airways';

      document.querySelector(".lang-toggle").textContent = lang === "ar" ? "English" : "العربية";

      document.getElementById("content-text").innerHTML = lang === 'ar' ? `
        تُعتبر الخطوط الجوية السودانية، المعروفة باسم "سودانير" (Sudan Airways)، الذراع الجوية للسودان منذ تأسيسها عام ١٩٤٦، مما يجعلها واحدة من أقدم شركات الطيران في أفريقيا والعالم العربي. نشأت بعد الحرب العالمية الثانية، بدأت رحلتها بطائرات دوغلاس دي سي-٣، وساهمت في ربط السودان بالعالم خلال حقبة الاستعمار البريطاني-المصري.<br><br>

        <strong>التاريخ: من التأسيس إلى التوسع</strong><br>
        بدأت "سودانير" برحلات محلية وإقليمية، ثم توسعت في الستينيات والسبعينيات بأسطول حديث شمل طائرات مثل البوينغ ٧٠٧ و٧٣٧، بالإضافة إلى طائرات "فوكر إف-٢٧" للرحلات القصيرة. بحلول الثمانينيات، أصبحت تُشغل رحلات منتظمة إلى أوروبا (لندن، فرانكفورت)، وإلى دول عربية مثل مصر والسعودية، ودول أفريقية ككينيا وإثيوبيا.<br><br>

        <strong>الشبكة والأسطول: بين الماضي والحاضر</strong><br>
        امتلكت الشركة تاريخياً أسطولاً متنوعاً، لكنه تراجع بسبب العقوبات الاقتصادية ونقص الصيانة. تشمل الطائرات التي استخدمتها:<br>
        - طائرات الركاب: بوينغ ٧٠٧، ٧٣٧، إيرباص إيه٣٠٠، وإيه٣٢٠.<br>
        - طائرات شحن: مثل أنتونوف.<br>
        - طائرات إقليمية: فوكر ٥٠ و٥٠٠.<br>
        أما الشبكة، فشملت محطات محلية كجوبا (قبل انفصال جنوب السودان)، وبورتسودان، وأقاليم دارفور، ودولياً إلى القاهرة، دبي، جدة، وإسطنبول.<br><br>

        <strong>التحديات: عقبات اقتصادية وسياسية</strong><br>
        واجهت "سودانير" تحديات جسيمة:<br>
        1. العقوبات الدولية، خاصة منذ التسعينيات.<br>
        2. انفصال جنوب السودان عام ٢٠١١.<br>
        3. الحظر الأوروبي في ٢٠٠٨.<br>
        4. الأزمات الداخلية (دارفور، الأزمة الاقتصادية، الاضطرابات السياسية).<br>
        5. كوفيد-١٩ والحرب الأهلية ٢٠٢٣.<br><br>

        <strong>محاولات التطوير والصمود</strong><br>
        - شراء طائرات مستعملة مثل إيرباص إيه٣٢٠.<br>
        - شراكات مع شركات مثل الخطوط الإثيوبية.<br>
        - مبادرات حكومية لإعادة الهيكلة وخصخصة جزئية.<br><br>

        <strong>الدور الثقافي والاقتصادي</strong><br>
        ظلت "سودانير" رمزاً للفخر الوطني، ووسيلة حيوية لربط المناطق النائية، خاصة في دارفور وكردفان، كما ساهمت في تنشيط السياحة الدينية (مثل زيارة أهرامات مروي).
      ` : `
        Sudan Airways (Sudanair): A Symbol of History and Challenges<br><br>

        Sudan Airways, better known as "Sudanair," has been the air arm of Sudan since its founding in 1946, making it one of the oldest airlines in Africa and the Arab world. Established after World War II, it began its journey with Douglas DC-3 aircraft and contributed to connecting Sudan to the world during the British-Egyptian colonial era.<br><br>

        <strong>History: From Establishment to Expansion</strong><br>
        Sudanair began with local and regional flights, then expanded in the 1960s and 1970s with a modern fleet that included Boeing 707 and 737 aircraft, along with Fokker F-27s for short-haul routes. By the 1980s, it operated regular flights to Europe (London, Frankfurt), Arab nations like Egypt and Saudi Arabia, and African countries like Kenya and Ethiopia.<br><br>

        <strong>Network and Fleet: Past and Present</strong><br>
        The company historically had a diverse fleet, which declined due to economic sanctions and lack of maintenance. It operated:<br>
        - Passenger aircraft: Boeing 707, 737, Airbus A300, and A320.<br>
        - Cargo aircraft: including Antonov.<br>
        - Regional aircraft: Fokker 50 and 500.<br>
        Its network included domestic destinations like Juba (before South Sudan's secession), Port Sudan, and Darfur regions, and international routes to Cairo, Dubai, Jeddah, and Istanbul.<br><br>

        <strong>Challenges: Economic and Political Obstacles</strong><br>
        Sudanair faced major hurdles:<br>
        1. International sanctions, especially from the 1990s.<br>
        2. South Sudan’s secession in 2011.<br>
        3. European ban in 2008.<br>
        4. Domestic crises (Darfur, inflation, political instability).<br>
        5. COVID-19 and the 2023 civil war.<br><br>

        <strong>Development and Resilience Efforts</strong><br>
        - Purchase of used aircraft like the Airbus A320.<br>
        - Partnerships with carriers like Ethiopian Airlines.<br>
        - Government initiatives for restructuring and partial privatization.<br><br>

        <strong>Cultural and Economic Role</strong><br>
        SudanAir remains a source of national pride and a vital lifeline connecting remote regions, especially Darfur and Kordofan. It also promotes religious tourism, including visits to the Meroe pyramids.
      `;
    }

    function goToHome() {
      window.location.href = "index.php";
    }
  </script>
</body>
</html>
