<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <title>سافر عبرنا - سودانير</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- خط عربي -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">

    <!-- تنسيقات خارجية -->
    <link rel="stylesheet" href="styles/index.css">
    <link rel="stylesheet" href="styles/header-style.css">
    <link rel="stylesheet" href="styles/footer-style.css">

    <style>
        body {
            font-family: 'Cairo', sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            color: #222;
        }

        .top-bar {
            background-color: #222;
            color: white;
            text-align: center;
            padding: 60px 10px 40px;
            position: relative;
        }

        .top-bar h1 {
            margin: 0;
            font-size: 2.5em;
        }

        .back-button {
            position: absolute;
            top: 15px;
            left: 15px;
            background-color: transparent;
            color: white;
            border: 2px solid white;
            padding: 8px 18px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 1em;
        }

        .back-button:hover {
            background-color: white;
            color: #222;
        }

        .lang-toggle {
            position: fixed;
            top: 10px;
            right: 10px;
            background-color: rgba(51, 202, 207, 0.4);
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            z-index: 999;
        }

        .lang-toggle:hover {
            background-color: rgba(40, 167, 69, 0.6);
        }

        .section {
            padding: 40px 20px;
            text-align: center;
        }

        .section h2 {
            color: #007bff;
            margin-bottom: 20px;
        }

        .section p {
            font-size: 1.1em;
            line-height: 1.7;
        }

        .map {
            max-width: 600px;
            margin: 20px auto;
        }

        .map img {
            width: 100%;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        footer {
            background-color: #222;
            color: white;
            padding: 30px 20px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .about, .contacts {
            flex: 1;
            min-width: 250px;
            margin-bottom: 20px;
        }

        .contacts-side .contact a {
            color: #ccc;
            text-decoration: none;
        }

        .contacts-side .contact a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <button onclick="toggleLanguage()" class="lang-toggle" id="langBtn">English</button>

    <!-- رأس الصفحة -->
    <div class="top-bar">
        <a href="index.php" class="back-button">الرجوع</a>
        <h1 id="pageTitle">سافر عبرنا</h1>
    </div>

    <!-- قسم الوجهات العالمية -->
    <div class="section">
        <h2 id="globalTitle">وجهات عالمية</h2>
        <p id="globalText">نقدم رحلات إلى وجهات عالمية متعددة مع التزامنا بالجودة والراحة.</p>
        <div class="map">
            <img src="imgs/mm2.png" alt="خريطة مطارات العالم">
        </div>
    </div>

    <!-- قسم الوجهات المحلية -->
    <div class="section">
        <h2 id="localTitle">وجهات محلية</h2>
        <p id="localText">نغطي معظم المدن السودانية عبر رحلات محلية مريحة وفعّالة.</p>
        <div class="map">
            <img src="imgs/q1.png" alt="خريطة مطارات السودان">
        </div>
    </div>

    <!-- تذييل -->
    <footer>
        <div class="about">
            <h3 id="aboutTitle">من نحن</h3>
            <p id="aboutDesc">
                الخطوط الجوية السودانية هي الناقل الوطني الرسمي، وتهدف إلى تقديم أفضل خدمات الطيران للمسافرين من وإلى السودان، مع الالتزام بالجودة والسلامة والمواعيد.
            </p>
        </div>
        <div class="contacts">
            <h3 id="contactTitle">تواصل معنا</h3>
            <div class="contacts-side">
                <div class="contact" id="country">السودان</div>
                <div class="contact"><a href="tel:+249912110765">+249912110765</a></div>
                <div class="contact"><a href="mailto:info@sudanair.sd">info@sudanair.sd</a></div>
                <div class="contact" id="hours">24 ساعة</div>
            </div>
        </div>
    </footer>

    <!-- جافاسكربت لتغيير اللغة -->
    <script>
        let currentLang = localStorage.getItem("lang") || "ar";

        function applyLanguage(lang) {
            document.documentElement.lang = lang;
            document.documentElement.dir = (lang === "ar") ? "rtl" : "ltr";
            document.getElementById("langBtn").textContent = (lang === "ar") ? "English" : "العربية";

            if (lang === "ar") {
                document.getElementById("pageTitle").textContent = "سافر عبرنا";
                document.getElementById("globalTitle").textContent = "وجهات عالمية";
                document.getElementById("globalText").textContent = "نقدم رحلات إلى وجهات عالمية متعددة  مع التزامنا بالجودة والراحة.";
                document.getElementById("localTitle").textContent = "وجهات محلية";
                document.getElementById("localText").textContent = "نغطي معظم المدن السودانية عبر رحلات محلية مريحة وفعّالة.";
                document.getElementById("aboutTitle").textContent = "من نحن";
                document.getElementById("aboutDesc").textContent = "الخطوط الجوية السودانية هي الناقل الوطني الرسمي، وتهدف إلى تقديم أفضل خدمات الطيران للمسافرين من وإلى السودان، مع الالتزام بالجودة والسلامة والمواعيد.";
                document.getElementById("contactTitle").textContent = "تواصل معنا";
                document.getElementById("country").textContent = "السودان";
                document.getElementById("hours").textContent = "24 ساعة";
            } else {
                document.getElementById("pageTitle").textContent = "Travel with Us";
                document.getElementById("globalTitle").textContent = "International Destinations";
                document.getElementById("globalText").textContent = "We offer flights to various international destinations  with a commitment to quality and comfort.";
                document.getElementById("localTitle").textContent = "Domestic Destinations";
                document.getElementById("localText").textContent = "We cover most Sudanese cities through convenient and efficient domestic flights.";
                document.getElementById("aboutTitle").textContent = "About Us";
                document.getElementById("aboutDesc").textContent = "Sudan Airways is the national carrier, committed to offering the best air services for passengers to and from Sudan, with a focus on quality, safety, and punctuality.";
                document.getElementById("contactTitle").textContent = "Contact Us";
                document.getElementById("country").textContent = "Sudan";
                document.getElementById("hours").textContent = "24 Hr";
            }

            localStorage.setItem("lang", lang);
            currentLang = lang;
        }

        function toggleLanguage() {
            applyLanguage(currentLang === "ar" ? "en" : "ar");
        }

        applyLanguage(currentLang);
    </script>
</body>
</html>
