<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>الخطوط الجوية السودانية</title>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet"/>

  <style>
    :root {
      --main-color: #013b82;
      --secondary-color: #f4f4f4;
      --text-color: #333;
    }

    body {
      margin: 0;
      font-family: 'Cairo', sans-serif;
      background-color: var(--secondary-color);
      color: var(--text-color);
    }

    header {
      background-color: white;
      color: var(--main-color);
      padding: 10px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .logo-container {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .logo-container img {
      width: 50px;
      height: auto;
    }

    .logo-container h1 {
      margin: 0;
      font-size: 1.6em;
      font-weight: bold;
      color: var(--main-color);
    }

    .lang-toggle {
      background-color: var(--main-color);
      color: white;
      border: none;
      padding: 6px 12px;
      border-radius: 6px;
      font-size: 14px;
      cursor: pointer;
      font-weight: bold;
    }

    .hero-section {
      position: relative;
      height: 500px;
      overflow: hidden;
    }

    .hero-images {
      position: relative;
      height: 100%;
    }

    .hero-images img {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
      opacity: 0;
      transition: opacity 1s ease-in-out;
      z-index: 1;
    }

    .hero-images img.active {
      opacity: 1;
      z-index: 2;
    }

    .indicators {
      position: absolute;
      bottom: 10px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      gap: 8px;
      z-index: 3;
    }

    .indicator {
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background-color: rgba(255, 255, 255, 0.5);
      border: 1px solid #fff;
      transition: background-color 0.3s;
    }

    .indicator.active {
      background-color: var(--main-color);
    }

    .hero-caption {
      text-align: center;
      background-color: rgba(251, 253, 255, 0.8);
      color: var(--main-color) ;
      padding: 15px;
      font-size: 1.5em;
      font-weight: bold;
    }

    .scroll-menu {
     display: flex
;
    overflow-x: auto;
    overflow-y: hidden;
    scroll-behavior: smooth;
    background-color: white;
    border-top: 1px solid #ddd;
    border-bottom: 1px solid #ddd;
    padding: 10px 0;
    white-space: nowrap;
    -webkit-overflow-scrolling: touch;
    justify-content: space-around;
    }

    .scroll-menu::-webkit-scrollbar {
      display: none;
    }

    .scroll-menu a {
      display: inline-block;
      padding: 10px 20px;
      text-decoration: none;
      color: var(--main-color);
      font-weight: bold;
      transition: background 0.3s;
    }

    .scroll-menu a:hover {
      background-color: #f0f0f0;
    }

    .section-title {
      text-align: center;
      padding: 30px 10px 10px;
      font-size: 1.8em;
      color: var(--main-color);
      margin: 0 20px 30px;
    }

    .main-con {
      display: flex;
      justify-content: space-around;
      flex-wrap: wrap;
      gap: 20px;
      padding: 30px 10px;
    }

    .service-card {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      width: 300px;
      overflow: hidden;
      position: relative;
    }

    .service-card img {
      width: 100%;
      height: 220px;
      object-fit: cover;
      border-bottom: 1px solid #eee;
    }

    .service-card .bounce {
      position: absolute;
      top: 15px;
      right: 15px;
      background-color: var(--main-color);
      color: white;
      padding: 8px 14px;
      border-radius: 5px;
      font-size: 14px;
      text-decoration: none;
      z-index: 2;
      transition: background-color 0.3s ease;
    }

    .service-card .bounce:hover {
      background-color: #002c63;
    }

    .service-card p {
      padding: 20px;
      font-size: 1em;
      margin: 0;
    }

    .bounce {
      background-color: var(--main-color);
      color: white;
      padding: 10px 20px;
      text-decoration: none;
      border-radius: 5px;
      display: inline-block;
      transition: background-color 0.3s ease;
    }

    .bounce:hover {
      background-color: #002c63;
    }

    footer {
      background-color: #222;
      color: white;
      padding: 40px 20px;
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
    }

    footer div {
      width: 45%;
      min-width: 200px;
    }

    footer h3 {
      border-bottom: 2px solid #888;
      padding-bottom: 10px;
      margin-bottom: 15px;
    }

    footer a {
      color: white;
      text-decoration: underline;
    }

    @media (max-width: 768px) {
      .main-con {
        flex-direction: column;
        align-items: center;
      }

      footer {
        flex-direction: column;
        align-items: center;
      }

      footer div {
        width: 90%;
        margin-bottom: 20px;
      }
    }
  </style>
</head>

<body>

<header>
  <div class="logo-container">
    <img src="imgs/m2.png" alt="شعار سودانير">
    <h3 id="title">الخطوط الجوية السودانية</h>
  </div>
  <button onclick="toggleLanguage()" class="lang-toggle" id="langBtn">English</button>
</header>

<div class="hero-section">
  <div class="hero-images" id="heroImages">
    <img src="imgs/k1.png" class="active" alt="banner"/>
    <img src="imgs/k2.png" alt="banner"/>
    <img src="imgs/k3.png" alt="banner"/>
    <img src="imgs/k4.png" alt="banner"/>
    <img src="imgs/k5.png" alt="banner"/>
    <img src="imgs/k6.png" alt="banner"/>
  </div>
  <div class="indicators" id="indicators"></div>
</div>
<div class="scroll-menu">
  <a href="#services" id="servicesNav">الخدمات</a>
  <a href="offices.php" id="aboutNav">مكاتبنا</a>
  <a href="#contact" id="contactNav">تواصل معنا</a>
  <a href="manager.php" id="gmLink"> المدير العام</a>
  <a href="news.php" id="newsLink">الأخبار</a>
</div>

<div class="hero-caption" id="heroText">نأخذك إلى وجهتك بثقة وأمان</div>

<h2 class="section-title" id="aboutTitle">من نحن</h2>
<div style="text-align: center; padding: 0 20px 30px;" id="aboutDesc">
  الخطوط الجوية السودانية (سودانير) هي الناقل الوطني الرسمي لجمهورية السودان منذ عام 1946. نقدم خدمات السفر والشحن الجوي بكفاءة عالية، ونلتزم بالسلامة والجودة والمواعيد الدقيقة.
</div>
<center>
  <a href="more.php" class="bounce" id="readMoreBtn">قراءة المزيد</a>
</center>

<h2 class="section-title" id="servicesTitle">خدماتنا</h2>
<section class="main-con" id="services">
  <div class="service-card">
    <a href="services.php" class="bounce" id="servicesBtn">الخدمات</a>
    <img src="imgs/j1.png" alt="خدمة العملاء"/>
    <p id="service1">وفر وقتك من خلال موقعنا الإلكتروني وخدمة العملاء 24/7.</p>
  </div>
  <div class="service-card">
    <a href="manage-trip.php" class="bounce" id="manageBtn">أدر رحلتك</a>
    <img src="imgs/j2.png" alt="الشحن الجوي"/>
    <p id="service2">نقدم خدمات الشحن الجوي داخليًا وخارجيًا بكفاءة عالية.</p>
  </div>
  <div class="service-card">
    <a href="with us.php" class="bounce" id="officesBtn">سافر عبرنا</a>
    <img src="imgs/s2.png" alt="سافر عبرنا"/>
    <p id="service3">اكتشف عروضنا المميزة وخيارات السفر المتنوعة عبر شبكتنا الجوية</p>
  </div>
</section>

<footer id="contact">
  <div>
    <h3 id="footerAbout">عن سودانير</h3>
    <p id="footerDesc">نحن نسعى لتقديم تجربة سفر آمنة ومريحة لعملائنا مع التركيز على الجودة والخدمة المتميزة.</p>
  </div>
  <div>
    <h3 id="footerContact">تواصل معنا</h3>
    
    <p>السودان - الخرطوم _ بورسودان</p>
    <!-- أزرار التواصل -->
<div style="display: flex; justify-content: center; gap: 25px; flex-wrap: wrap; text-align: center; padding: 20px 0; background-color: #1e1e1e;">
<!-- أزرار التواصل في صف واحد -->
<div style="display: flex; justify-content: center; gap: 15px; flex-wrap: wrap; text-align: center; padding: 20px 0; background-color: #1e1e1e;">

  <!-- زر واتساب -->
  <div style="width: 70px;">
    <a href="#">
      <img src="imgs/whatsapp.png" alt="واتساب" style="width: 40px; height: 40px;">
    </a>
    <p style="color: white; font-size: 14px; margin: 5px 0 0;">واتساب</p>
  </div>

  <!-- زر فيسبوك -->
  <div style="width: 70px;">
    <a href="https://www.facebook.com/profile.php?id=100086753468469" target="_blank">
      <img src="imgs/facebook.png" alt="فيسبوك" style="width: 40px; height: 40px;">
    </a>
    <p style="color: white; font-size: 14px; margin: 5px 0 0;">فيسبوك</p>
  </div>

  <!-- زر الإيميل -->
  <div style="width: 70px;">
    <a href="mailto:info@sudanair.sd">
      <img src="imgs/email.png" alt="إيميل" style="width: 40px; height: 40px;">
    </a>
    <p style="color: white; font-size: 14px; margin: 5px 0 0;">إيميل</p>
  </div>

  <!-- زر الاتصال -->
  <div style="width: 70px;">
    <a href="tel:+249912110765">
      <img src="imgs/phone.png" alt="اتصال" style="width: 40px; height: 40px;">
    </a>
    <p style="color: white; font-size: 14px; margin: 5px 0 0;">اتصال</p>
  </div>
     <p id="hours">ساعات العمل: 24 ساعة</p>
  </div>
</footer>

<script>
  const translations = {
    ar: {
      langBtn: "English",
      title: "الخطوط الجوية السودانية",
      servicesNav: "الخدمات",
      aboutNav: "مكاتبنا",
      contactNav: "تواصل معنا",
      gmLink: " المدير العام",
      newsLink: "الأخبار",
      heroText: "نأخذك إلى وجهتك بثقة وأمان",
      aboutTitle: "من نحن",
      aboutDesc: `الخطوط الجوية السودانية (سودانير) هي الناقل الوطني الرسمي لجمهورية السودان منذ عام 1946. نقدم خدمات السفر والشحن الجوي بكفاءة عالية، ونلتزم بالسلامة والجودة والمواعيد الدقيقة.`,
      readMoreBtn: "قراءة المزيد",
      servicesTitle: "خدماتنا",
      service1: "وفر وقتك من خلال موقعنا الإلكتروني وخدمة العملاء 24/7.",
      service2: "نقدم خدمات الشحن الجوي داخليًا وخارجيًا بكفاءة عالية.",
      service3: "اكتشف عروضنا المميزة وخيارات السفر المتنوعة عبر شبكتنا الجوية",
      servicesBtn: "الخدمات",
      manageBtn: "أدر رحلتك",
      officesBtn: "سافر عبرنا",
      footerAbout: "عن سودانير",
      footerDesc: "نحن نسعى لتقديم تجربة سفر آمنة ومريحة لعملائنا مع التركيز على الجودة والخدمة المتميزة.",
      footerContact: "تواصل معنا",
      hours: "ساعات العمل: 24 ساعة"
    },
    en: {
      langBtn: "عربي",
      title: "Sudan Airways",
      servicesNav: "Services",
      aboutNav: "Our Offices",
      contactNav: "Contact",
      gmLink: "General Manager ",
      newsLink: "News",
      heroText: "We take you to your destination with safety and trust",
      aboutTitle: "About Us",
      aboutDesc: `Sudan Airways (Sudanair) is the national carrier of Sudan since 1946. We provide efficient travel and cargo services, committed to safety, quality and punctuality.`,
      readMoreBtn: "Read More",
      servicesTitle: "Our Services",
      service1: "Save time through our website and 24/7 customer support.",
      service2: "We provide efficient domestic and international air cargo services.",
      service3: "Explore our office locations inside and outside Sudan.",
      servicesBtn: "Services",
      manageBtn: "Manage Trip",
      officesBtn: "Fly With Us",
      footerAbout: "About Sudan Airways",
      footerDesc: "We aim to provide safe and comfortable travel experience with focus on quality and excellent service.",
      footerContact: "Contact Us",
      hours: "Working Hours: 24 Hours"
    }
  };

  function applyLanguage(lang) {
    currentLang = lang;
    localStorage.setItem("lang", lang);
    const t = translations[lang];
    for (const id in t) {
      const el = document.getElementById(id);
      if (el) {
        el.innerText = t[id];
      }
    }
    document.body.dir = lang === "ar" ? "rtl" : "ltr";
    document.documentElement.lang = lang;
  }

  function toggleLanguage() {
    applyLanguage(currentLang === "ar" ? "en" : "ar");
  }

  let currentLang = localStorage.getItem("lang") || "ar";
  applyLanguage(currentLang);

  const heroImages = document.querySelectorAll("#heroImages img");
  const indicatorsContainer = document.getElementById("indicators");
  let currentIndex = 0;

  heroImages.forEach((_, idx) => {
    const dot = document.createElement("div");
    dot.classList.add("indicator");
    if (idx === 0) dot.classList.add("active");
    indicatorsContainer.appendChild(dot);
  });

  const indicators = document.querySelectorAll(".indicator");

  setInterval(() => {
    heroImages[currentIndex].classList.remove("active");
    indicators[currentIndex].classList.remove("active");

    currentIndex = (currentIndex + 1) % heroImages.length;

    heroImages[currentIndex].classList.add("active");
    indicators[currentIndex].classList.add("active");
  }, 3000);
</script>

</body>
</html>
