<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>أدر رحلتك</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- خط القاهرة -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">

    <!-- التنسيقات -->
    <link rel="stylesheet" href="styles/index.css">
    <link rel="stylesheet" href="styles/header-style.css">

    <style>
        body {
            font-family: 'Cairo', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            color: #222;
        }

        .page-header {
            background-color: #002b5c;
            color: #fff;
            padding: 60px 20px;
            position: relative;
            text-align: center;
            border-bottom-left-radius: 30px;
            border-bottom-right-radius: 30px;
        }

        .page-header h1 {
            margin: 0;
            font-size: 2.5em;
        }

        .lang-toggle, .back-button {
            position: absolute;
            top: 15px;
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }

        .lang-toggle {
            right: 15px;
            background-color: rgba(51, 202, 207, 0.4);
            color: #fff;
            border: none;
        }

        .lang-toggle:hover {
            background-color: rgba(40, 167, 69, 0.6);
        }

        .back-button {
            left: 15px;
            background-color: transparent;
            color: white;
            border: 2px solid white;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .back-button:hover {
            background-color: white;
            color: #002b5c;
        }

        .content {
            max-width: 900px;
            margin: 40px auto;
            background: #fff;
            padding: 30px 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .section {
            margin-bottom: 30px;
        }

        .section h2 {
            color: #007bff;
            margin-bottom: 10px;
            font-size: 1.6em;
        }

        .section h3 {
            color: #555;
            margin-top: 15px;
            font-size: 1.2em;
        }

        .section p {
            margin: 5px 0 10px;
            line-height: 1.8;
            font-size: 1.1em;
        }

        /* تنسيق الفوتر */
        .footer {
            background: #002b5c;
            color: white;
            padding: 40px 20px 20px;
            border-top-left-radius: 30px;
            border-top-right-radius: 30px;
            margin-top: 60px;
        }

        .footer-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            gap: 30px;
        }

        .footer-section {
            flex: 1;
            min-width: 250px;
        }

        .footer-section h3 {
            color: #ffffff;
            margin-bottom: 15px;
            font-size: 20px;
        }

        .footer-section p, .footer-section a {
            color: #ddd;
            text-decoration: none;
            font-size: 15px;
        }

        .footer-section a:hover {
            text-decoration: underline;
        }

        .footer-section ul {
            list-style: none;
            padding: 0;
        }

        .footer-section ul li {
            margin-bottom: 8px;
        }

        .footer-bottom {
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
            color: #aaa;
            border-top: 1px solid #444;
            padding-top: 15px;
        }
    </style>
</head>
<body>

    <div class="page-header">
        <a href="index.php" class="back-button">الرجوع</a>
        <button onclick="toggleLanguage()" class="lang-toggle" id="langBtn">English</button>
        <h1 id="pageTitle">أدر رحلتك</h1>
    </div>

    <div class="content" id="contentArea">
        <div class="section">
            <h2>1. قبل أن تسافر</h2>
            <h3>أ. متطلبات السفر</h3>
            <p>يرجى التأكد من صلاحية جواز السفر والتأشيرة قبل السفر، وقراءة شروط الدخول للوجهة المقصودة.</p>

            <h3>ب. إرشادات</h3>
            <p>الوصول إلى المطار قبل الرحلة بوقت كافٍ، والتأكد من حمل جميع المستندات المطلوبة والتذاكر.</p>
        </div>

        <div class="section">
            <h2>2. مطلوبات مطارات وجهاتنا</h2>
            <h3>أ. الركاب العابرين</h3>
            <p>قد تختلف الإجراءات للركاب العابرين حسب قوانين البلد. نوصي بالاطلاع المسبق على التعليمات.</p>

            <h3>ب. المعتمرون والمقيمون</h3>
            <p>يجب الالتزام بتعليمات السلطات المحلية، وإبراز الوثائق اللازمة مثل التصاريح والإقامات.</p>
        </div>

        <div class="section">
            <h2>3. الأمتعة</h2>
            <h3>أ. الأمتعة المسموح بها</h3>
            <p>يسمح للمسافرين بحمل حقيبة يد واحدة وحقيبة شحن وفقاً للوزن المسموح المحدد في التذكرة.</p>

            <h3>ب. المواد المحظورة</h3>
            <p>يُمنع حمل المواد القابلة للاشتعال أو المتفجرات أو السوائل غير المسموح بها داخل الأمتعة.</p>
        </div>
    </div>

    <!-- فوتر مطوّر مثل الصفحة الرئيسية -->
    <footer class="footer">
      <div class="footer-section">
            <h3 id="aboutTitle">من نحن</h3>
            <p id="aboutDesc">
                الخطوط الجوية السودانية هي الناقل الوطني الرسمي، وتهدف إلى تقديم أفضل خدمات الطيران للمسافرين من وإلى السودان، مع الالتزام بالجودة والسلامة والمواعيد.
            </p>
        </div>
        <div class="footer-section">
            <h3 id="contactTitle">تواصل معنا</h3>
            <div id="country">السودان</div>
            <a href="tel:+249912110765">+249912110765</a>
            <a href="mailto:info@sudanair.sd">info@sudanair.sd</a>
            <div id="hours">24 ساعة</div>
        </div>
    </footer>

    <!-- تغيير اللغة -->
    <script>
        let currentLang = localStorage.getItem("lang") || "ar";

        function applyLanguage(lang) {
            const langBtn = document.getElementById("langBtn");
            const pageTitle = document.getElementById("pageTitle");
            const contentArea = document.getElementById("contentArea");

            if (lang === "en") {
                document.documentElement.lang = "en";
                document.documentElement.dir = "ltr";
                langBtn.textContent = "العربية";
                pageTitle.textContent = "Manage Your Trip";
                contentArea.innerHTML = `
                    <div class="section">
                        <h2>1. Before You Travel</h2>
                        <h3>a. Travel Requirements</h3>
                        <p>Please ensure your passport and visa are valid, and check entry requirements for your destination.</p>

                        <h3>b. Guidelines</h3>
                        <p>Arrive at the airport early and bring all required documents and tickets with you.</p>
                    </div>
                    <div class="section">
                        <h2>2. Destination Airport Requirements</h2>
                        <h3>a. Transit Passengers</h3>
                        <p>Procedures may vary by country. Please review transit rules in advance.</p>

                        <h3>b. Pilgrims and Residents</h3>
                        <p>Follow local authorities' instructions and provide necessary documents such as permits and residency cards.</p>
                    </div>
                    <div class="section">
                        <h2>3. Baggage</h2>
                        <h3>a. Allowed Baggage</h3>
                        <p>Passengers are allowed one carry-on bag and checked luggage according to the ticket allowance.</p>

                        <h3>b. Prohibited Items</h3>
                        <p>Flammable, explosive items or restricted liquids are not allowed in luggage.</p>
                    </div>
                `;
                currentLang = "en";
            } else {
                document.documentElement.lang = "ar";
                document.documentElement.dir = "rtl";
                langBtn.textContent = "English";
                pageTitle.textContent = "أدر رحلتك";
                contentArea.innerHTML = `
                    <div class="section">
                        <h2>1. قبل أن تسافر</h2>
                        <h3>أ. متطلبات السفر</h3>
                        <p>يرجى التأكد من صلاحية جواز السفر والتأشيرة قبل السفر، وقراءة شروط الدخول للوجهة المقصودة.</p>

                        <h3>ب. إرشادات</h3>
                        <p>الوصول إلى المطار قبل الرحلة بوقت كافٍ، والتأكد من حمل جميع المستندات المطلوبة والتذاكر.</p>
                    </div>
                    <div class="section">
                        <h2>2. مطلوبات مطارات وجهاتنا</h2>
                        <h3>أ. الركاب العابرين</h3>
                        <p>قد تختلف الإجراءات للركاب العابرين حسب قوانين البلد. نوصي بالاطلاع المسبق على التعليمات.</p>

                        <h3>ب. المعتمرون والمقيمون</h3>
                        <p>يجب الالتزام بتعليمات السلطات المحلية، وإبراز الوثائق اللازمة مثل التصاريح والإقامات.</p>
                    </div>
                    <div class="section">
                        <h2>3. الأمتعة</h2>
                        <h3>أ. الأمتعة المسموح بها</h3>
                        <p>يسمح للمسافرين بحمل حقيبة يد واحدة وحقيبة شحن وفقاً للوزن المسموح المحدد في التذكرة.</p>

                        <h3>ب. المواد المحظورة</h3>
                        <p>يُمنع حمل المواد القابلة للاشتعال أو المتفجرات أو السوائل غير المسموح بها داخل الأمتعة.</p>
                    </div>
                `;
                currentLang = "ar";
            }

            localStorage.setItem("lang", currentLang);
        }

        function toggleLanguage() {
            applyLanguage(currentLang === "ar" ? "en" : "ar");
        }

        applyLanguage(currentLang);
    </script>
</body>
</html>
